'''A totally useless module for performing numerical operations using functions'''

def addition(a,b):
    '''A totally useless function for adding numbers'''
    return a+b

def subtraction(a,b):
    '''A totally useless function for subtracting numbers'''
    return a-b

def multiplication(a,b):
    '''A totally useless function for multiplying numbers'''
    return a*b

def division(a,b):
    '''A totally useless function for dividing numbers'''
    return a/b